Sergio Canales
Simon Canales

credenciales para activar base de datos:
Usuario: ISIS2304A031910
 
Password: MCXnCEJqOU

ver requerimientos bajo la pesta�a de requerimientos